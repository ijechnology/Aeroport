const String aviationstackApiKey = '66e9f045b56073d2f33d14857a5dce0f';

const String aviationEdgeApiKey = '66e9f045b56073d2f33d14857a5dce0f';

const String exchangeRateApiKey = 'e518fc3f0b5ff0f5dc94b21c04e8720c';
